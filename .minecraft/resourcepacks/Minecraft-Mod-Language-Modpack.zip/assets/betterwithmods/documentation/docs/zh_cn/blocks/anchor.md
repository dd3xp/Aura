![滑车锚](block:betterwithmods:anchor)

滑车锚用于连接麻绳
如果被放置在一般的方块上可以手持[绳子](../items/rope.md)点击以向下垂挂绳子，持续单击可以让麻绳尽可能的向下垂挂。而空手点击滑车锚则可以移除一格麻绳

如果将其放置在[平台](platform.md)或者[铁墙](iron_wall.md)的上方滑车锚就可以与[滑车](pulley.md)连接并连接成为一个滑轮平台

![一个基本的滑轮平台](betterwithmods:pulley1.png)